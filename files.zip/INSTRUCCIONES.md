# Instrucciones de instalación

## 1) Dependencia nueva
```
npm install @supabase/supabase-js @supabase/ssr
```

## 2) Variables de entorno (.env.local)
Agregá (sacás los valores de Supabase → Project Settings → API):
```
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=xxxxx
```
(La `anon key` es pública, no la `service_role`. Con RLS bien configurado —como está en el
SQL adjunto— alcanza y sobra: solo usuarios logueados pueden escribir.)

## 3) Base de datos
Copiá y corré `supabase_schema.sql` completo en el SQL Editor de tu proyecto Supabase.
Crea la tabla `products`, las políticas de seguridad, el bucket de imágenes público, y
de paso migra tus 3 productos actuales.

## 4) Crear el usuario admin (la dueña)
Supabase → Authentication → Users → Add user. Con ese email/password ya puede entrar en
`/admin/login`.

## 5) Copiar los archivos
Todos los archivos dentro de `src/` van al mismo path relativo dentro de tu proyecto.
`GraffitiBackground.tsx` y `route.ts` reemplazan a los que ya tenías (ver ubicaciones que
me pasaste antes).

## 6) Conectar el listado público a Supabase
Falta un paso chico que no pude hacer a ciegas: no tengo el código de `Collection.tsx`
todavía. Pasámelo y te dejo el cambio de una: la `page.tsx` principal (Server Component)
llama a `getPublishedProducts()` de `src/data/products.ts` y se lo pasa como prop a
`<Collection items={...} />`, en vez de que `Collection.tsx` importe `collectionItems`
directo del archivo estático. Mismo tipo `JewelryItem`, así que el resto del componente
no debería necesitar cambios.

## Cómo queda el flujo para la dueña
1. Entra a `tudominio.com/admin/login`
2. Ve la lista de productos, con botón "visible/oculto" para sacar algo de la vitrina
   sin borrarlo, "editar" y "borrar".
3. "+ nuevo producto" abre un formulario con subida de fotos directo a Supabase Storage
   (arrastra o selecciona archivos, no necesita FTP ni tocar `/public`).
4. Guarda → el sitio se actualiza al toque (revalidatePath), sin deploy.
