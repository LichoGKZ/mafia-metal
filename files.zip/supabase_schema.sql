-- ── Tabla de productos ──────────────────────────────────────────────
create table if not exists public.products (
  id text primary key,                    -- slug, ej: "one-love"
  name text not null,
  subtitle text default '',
  price text default '$—',                -- texto para mostrar
  price_ars numeric not null default 0,   -- numérico, para carrito/MP
  material text default '',
  description text default '',
  chapter text default '',
  badge text,                             -- "NEW", "BESTSELLER", null
  color text not null default 'silver',   -- 'gold' | 'silver' | 'mixed'
  image text default '',                  -- URL pública (foto principal)
  images text[] default '{}',             -- fotos de estudio (carrusel)
  lifestyle_images text[] default '{}',   -- fotos "as worn by"
  is_visible boolean not null default true, -- para ocultar sin borrar
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Mantener updated_at al día
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_products_updated_at on public.products;
create trigger trg_products_updated_at
  before update on public.products
  for each row execute function public.set_updated_at();

-- ── Seguridad (RLS) ─────────────────────────────────────────────────
alter table public.products enable row level security;

-- Cualquiera puede LEER productos visibles (para el sitio público)
create policy "Productos visibles son públicos"
  on public.products for select
  using (is_visible = true);

-- Solo usuarios autenticados (la dueña) pueden insertar/editar/borrar
create policy "Admins pueden insertar productos"
  on public.products for insert
  to authenticated
  with check (true);

create policy "Admins pueden editar productos"
  on public.products for update
  to authenticated
  using (true);

create policy "Admins pueden borrar productos"
  on public.products for delete
  to authenticated
  using (true);

-- Los admins también deben poder VER los ocultos (is_visible = false)
create policy "Admins ven todos los productos"
  on public.products for select
  to authenticated
  using (true);

-- ── Bucket de imágenes ──────────────────────────────────────────────
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

create policy "Lectura pública de imágenes de productos"
  on storage.objects for select
  using (bucket_id = 'product-images');

create policy "Admins pueden subir imágenes de productos"
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'product-images');

create policy "Admins pueden borrar imágenes de productos"
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'product-images');

-- ── Migración de tus 3 productos actuales (opcional, corré una vez) ─
insert into public.products
  (id, name, subtitle, price, price_ars, material, description, chapter, badge, color, image, images, lifestyle_images, sort_order)
values
  ('one-love', 'ONE LOVE', 'Ultimo lanzamiento.', '$—', 0, 'Plata',
   'El concepto One Love es una expresión que trasciende géneros. Sus raíces están profundamente ligadas a la cultura reggae como un llamado a la unidad. Fue el hip hop de los 90 —y fundamentalmente el clásico One Love de Nas— lo que la consolidó como un símbolo de lealtad y hermandad en el entorno urbano.',
   'I', 'BESTSELLER', 'silver', '/images/products/one-love-01.jpg',
   array['/images/products/one-love-01.jpg','/images/products/one-love-02.jpg','/images/products/one-love-03.jpg','/images/products/one-love-04.jpg'],
   array['/images/lifestyle/one-love-01.jpg','/images/lifestyle/one-love-02.jpg','/images/lifestyle/one-love-03.jpg','/images/lifestyle/one-love-04.jpg','/images/lifestyle/one-love-05.jpg','/images/lifestyle/one-love-06.jpg'],
   1),
  ('only-trust', 'ONLY TRUST', 'Only trust your mafia', '$—', 0, 'Plata maciza',
   'Pulsera de eslabones diseñada y modelada desde cero, pieza maciza y pesada, donde la estética industrial se logra a través de un trabajo preciso de textura y acabado en cada eslabón. Cada eslabón lleva el sello de Mafia Metal en la cara posterior. El cierre presenta la frase ''Only trust your mafia''.',
   'II', null, 'silver', '/images/products/only-trust.jpg', '{}', '{}', 2),
  ('tag-mafia', 'TAG MAFIA', 'El graffiti llevado al metal', '$—', 0, 'Plata',
   'El Tag de Mafia Metal traslada la estética del graffiti al metal. Diseñado y modelado desde cero, este colgante captura el trazo original en una pieza maciza, pensada para mantener la identidad del diseño intacta tras el proceso de fundición.',
   'III', 'NEW', 'silver', '', '{}', '{}', 3)
on conflict (id) do nothing;
